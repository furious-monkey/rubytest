require_relative 'terstmodule'

module Tester
	def try_this
		puts "try this"
	end
	
	def tryanother
		puts "try anohete"
	end
	
	def tryathurd
		puts "third   "
	end
end